package com.example.demon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemonApplicationTests {

    @Test
    void contextLoads() {
    }

}
